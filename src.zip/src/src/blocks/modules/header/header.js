const Header = class Header {
    constructor(){
        this.isModalOpened = false
    }
    toggleModal() {
        this.isModalOpened = !this.isModalOpened;
    }
    init() {}
}

export default Header;