const About = class About {
    constructor() {
        this.textsOpened = false;
    }
    toggleTexts() {
        this.textsOpened = !this.textsOpened
    }
}

export default About;