import Glide from '@glidejs/glide';

const Benefits = class Benefits {
    constructor() {
        this.topSlider = null;
        this.bottomSlider = null;
        this.index = 0;
    }
    initTopSlider() {
        if (!document.querySelector('.benefits__top_glide')) return;
        this.topSlider = new Glide('.benefits__top_glide', {
            perView: 1,
            gap: 20
        }).mount();
    }
    initBottomSlider() {
        if (!document.querySelector('.benefits__bottom_glide')) return;

        this.bottomSlider = new Glide('.benefits__bottom_glide', {
            perView: 1,
            gap: 20
        }).mount();

        if (!document.querySelector('.benefits__top_glide')) return;

        this.topSlider.on(['run'], () => {
            // console.log(this.topSlider.index);
            this.bottomSlider.go(`=${this.topSlider.index}`);
        });
        this.bottomSlider.on(['run'], () => {
            // console.log(this.topSlider.index);
            this.topSlider.go(`=${this.bottomSlider.index}`);
            this.index = this.topSlider.index;
        })
    }
    init() {
        this.initTopSlider();
        this.initBottomSlider();        
    }
};

export default Benefits;