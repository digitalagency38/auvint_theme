import * as globalFunctions from './modules/functions.js';
globalFunctions.isWebp();

import Vue from 'vue/dist/vue.js';
import $ from 'jquery';

import Header from '../blocks/modules/header/header.js';
import Modals from '../blocks/modules/modals/modals.js';
import MainSlider from '../blocks/modules/main_slider/main_slider.js';
import Projects from '../blocks/modules/projects/projects.js';
import Benefits from '../blocks/modules/benefits/benefits.js';
import Clients from '../blocks/modules/clients/clients.js';
import Sertificates from '../blocks/modules/sertificates/sertificates.js';
import News from '../blocks/modules/news/news.js';
import Solutions from '../blocks/modules/solutions/solutions.js';
import Production from '../blocks/modules/production/production.js';
import About from '../blocks/modules/about/about.js';

window.app = new Vue({
    el: '#app',
    data: () => ({
        isMounted: false,
        sizes: {
            tablet: 1024,
            mobile: 768,
            window: window.innerWidth
        },
        header: new Header({
            someVareible: 'someVareible'
        }),
        modals: new Modals({
            modalsSelector: "data-modal",
            modalsOpenerSelector: "data-modal-id",
            openedClass: "isOpened"
        }),
        mainSlider: new MainSlider(),
        projects: new Projects(),
        benefits: new Benefits(),
        clients: new Clients(),
        sertificates: new Sertificates(),
        news: new News(),
        solutions: new Solutions(),
        production: new Production(),
        about: new About(),
    }),
    beforeMount() {        
        window.addEventListener('resize', () => {
            this.sizes.window = window.innerWidth;
        });
    },
    mounted() {
        this.isMounted = true;
        this.header.init();
        this.modals.init();
        this.mainSlider.init();
        this.projects.init();
        this.benefits.init();
        this.clients.init();
        this.sertificates.init();
        this.news.init();
        this.solutions.init();
        this.production.init();
    },
    computed: {
        isMobile: function () {
            return this.sizes.window < this.sizes.mobile;
        },
        isTablet: function () {
            return this.sizes.window < this.sizes.tablet && this.sizes.window > this.sizes.mobile;
        }
    },
});